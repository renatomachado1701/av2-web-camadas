package br.com.pessoacontato.pwc.domain.exception;

public class EntidadeNaoEncontradaException extends NegocioException {

	private static final long serialVersionUID = 820588242792903294L;

	public EntidadeNaoEncontradaException(String msg) {
		super(msg);
	}

	
}
