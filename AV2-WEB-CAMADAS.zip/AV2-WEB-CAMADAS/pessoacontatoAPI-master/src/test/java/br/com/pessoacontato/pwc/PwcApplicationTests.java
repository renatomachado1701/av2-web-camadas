package br.com.pessoacontato.pwc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PwcApplicationTests {

	@Test
	void contextLoads() {
	}

}
